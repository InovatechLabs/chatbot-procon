import React, { useEffect, useState } from 'react';
import { adminService } from './services/api';
import './App.css';

interface KPI {
  totalInteracoes: number;
  usuariosUnicos: number;
  taxaConclusao: string;
  totalNos: number;
}

interface AlternativaRanking {
  id: string;
  texto: string;
  cliques: number;
}

interface NoRanking {
  id: string;
  titulo: string;
  tipo: string;
  visitas: number;
}

const IconMessage = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
  </svg>
);
const IconUsers = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>
);
const IconCheck = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>
  </svg>
);
const IconNodes = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>
  </svg>
);
const IconTrendUp = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>
  </svg>
);
const IconTrendDown = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/>
  </svg>
);

export default function Analytics() {
  const [kpis, setKpis] = useState<KPI | null>(null);
  const [graficoLinha, setGraficoLinha] = useState<{ data: string; interacoes: number }[]>([]);
  const [rankingBotoes, setRankingBotoes] = useState<AlternativaRanking[]>([]);
  const [rankingNos, setRankingNos] = useState<NoRanking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    carregarAnalytics();
  }, []);

  const carregarAnalytics = async () => {
    setLoading(true);
    try {
      const resAnalytics = await adminService.getAnalytics();
      const data = resAnalytics?.data || {};

      setKpis(data.metricas || null);
      setGraficoLinha(Array.isArray(data.historicoDiario) ? data.historicoDiario : []);
      setRankingBotoes(Array.isArray(data.topBotoes) ? data.topBotoes : []);
      setRankingNos(Array.isArray(data.nosMaisVisitados) ? data.nosMaisVisitados : []);
    } catch (err) {
      console.error('Erro ao carregar analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading-screen">Carregando Análises...</div>;
  }

  const safeGrafico = (graficoLinha || []).filter(item => item && typeof item.interacoes === 'number');
  const maxChartVal = safeGrafico.length > 0 ? Math.max(...safeGrafico.map(g => g.interacoes), 1) : 1;

  return (
    <main className="tab-content analytics-view">
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-icon kpi-icon-blue"><IconMessage /></div>
          <div className="kpi-info">
            <div className="kpi-label">Interações totais</div>
            <div className="kpi-value">{kpis?.totalInteracoes?.toLocaleString('pt-BR') || '0'}</div>
            <div className="kpi-delta up"><IconTrendUp /> +12% <span>vs semana passada</span></div>
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon kpi-icon-purple"><IconUsers /></div>
          <div className="kpi-info">
            <div className="kpi-label">Usuários únicos</div>
            <div className="kpi-value">{kpis?.usuariosUnicos?.toLocaleString('pt-BR') || '0'}</div>
            <div className="kpi-delta up"><IconTrendUp /> +8% <span>vs semana passada</span></div>
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon kpi-icon-green"><IconCheck /></div>
          <div className="kpi-info">
            <div className="kpi-label">Taxa de conclusão</div>
            <div className="kpi-value">{kpis?.taxaConclusao || '100%'}</div>
            <div className="kpi-delta up"><IconTrendUp /> +5% <span>vs semana passada</span></div>
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon kpi-icon-orange"><IconNodes /></div>
          <div className="kpi-info">
            <div className="kpi-label">Nós no fluxo</div>
            <div className="kpi-value">{kpis?.totalNos || '0'}</div>
            <div className="kpi-delta down"><IconTrendDown /> -2 <span>novos esta semana</span></div>
          </div>
        </div>
      </div>

      <section className="chart-card">
        <div className="chart-header">
          <div>
            <h3>Interações nos últimos 14 dias</h3>
            <p className="chart-subtitle">Volume diário de mensagens trocadas no WhatsApp</p>
          </div>
          <div className="chart-legend">
            <span><span className="chart-dot chart-dot-primary"></span>Interações</span>
          </div>
        </div>
        <div className="bar-chart">
          {safeGrafico.length > 0 ? (
            safeGrafico.map((item, index) => {
              const valor = item?.interacoes ?? 0;
              const h = Math.max(6, (valor / maxChartVal) * 100);
              return (
                <div key={item?.data || index} className="bar-col">
                  <div className="bar-wrapper">
                    <div className="bar" style={{ height: `${h}%` }}>
                      <div className="bar-tooltip">
                        <strong>{item?.data || 'Sem data'}</strong>
                        <span>{valor} interações</span>
                      </div>
                    </div>
                  </div>
                  <span className="bar-label">{item?.data || ''}</span>
                </div>
              );
            })
          ) : (
            <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
              Nenhum histórico disponível.
            </div>
          )}
        </div>
      </section>

      <div className="tables-grid">
        <section className="table-card">
          <div className="table-header">
            <h3>Top botões mais clicados</h3>
            <span className="table-count">{(rankingBotoes || []).length} registros</span>
          </div>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Opção</th>
                  <th className="text-right">Cliques</th>
                </tr>
              </thead>
              <tbody>
                {(rankingBotoes || []).map(b => (
                  <tr key={b.id}>
                    <td><span className="table-strong">{b.texto}</span></td>
                    <td className="text-right"><span className="count-pill">{(b.cliques || 0).toLocaleString('pt-BR')}</span></td>
                  </tr>
                ))}
                {(rankingBotoes || []).length === 0 && (
                  <tr><td colSpan={2} className="no-data">Nenhum clique registrado ainda.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <section className="table-card">
          <div className="table-header">
            <h3>Nós mais visitados</h3>
            <span className="table-count">{(rankingNos || []).length} registros</span>
          </div>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Título</th>
                  <th>Tipo</th>
                  <th className="text-right">Visitas</th>
                </tr>
              </thead>
              <tbody>
                {(rankingNos || []).map(n => (
                  <tr key={n.id}>
                    <td><span className="table-strong">{n.titulo}</span></td>
                    <td><span className={`tag badge-${n.tipo}`}>{n.tipo || 'pergunta'}</span></td>
                    <td className="text-right"><span className="count-pill">{(n.visitas || 0).toLocaleString('pt-BR')}</span></td>
                  </tr>
                ))}
                {(rankingNos || []).length === 0 && (
                  <tr><td colSpan={3} className="no-data">Nenhum acesso registrado.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </main>
  );
}